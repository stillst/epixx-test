hides = document.querySelectorAll(".hide");
hidesClick();

function hidesClick(){
  for(var i=0; i < hides.length; i++ ){
      hides[i].addEventListener("click", handleClick);
  }
}

function handleClick(e){
  this.classList.toggle("hide");
}


//timer
var now=new Date();
var minute=now.getMinutes() + 10;
var tz=+3;
/*
var minutes = 1000 * 60;
var hours = minutes * 60;
var days = hours * 24;
var years = days * 365;
var d = new Date();
var t = d.getTime();
var y = Math.round(t / years);
*/
countdown(minute);

function countdown(min){
    theminute=min;
    var today=new Date();
    var todaymin=today.getMinutes();
    var todaysec=today.getSeconds();
    var todaystring1="21 May 1958 10:"+todaymin+":"+todaysec;
    var todaystring=Date.parse(todaystring1)+(tz*1000*60*60);
    var futurestring1="21 May 1958 10:"+min;
    var futurestring=Date.parse(futurestring1)-(today.getTimezoneOffset()*(1000*60));
    var dd=futurestring-todaystring;
    var dmin=Math.floor(((dd%(60*60*1000*24))%(60*60*1000))/(60*1000)*1);
    var dsec=Math.floor((((dd%(60*60*1000*24))%(60*60*1000))%(60*1000))/1000*1);

    if(dmin<=0&&dsec<=0)
    {
        document.getElementById('dmin').style.display="none";
        document.getElementById('dsec').style.display="none";
        document.querySelector(".timer__txt").innerHTML="Время истекло!";
        return;
    }
    else
    {
        document.getElementById('dmin').innerHTML=dmin+" :";
        if (dsec > 9){
            document.getElementById('dsec').innerHTML=dsec;
        }
        else{
             document.getElementById('dsec').innerHTML= "0" + dsec;
        }
        setTimeout("countdown(theminute)",1000);
    }
}
